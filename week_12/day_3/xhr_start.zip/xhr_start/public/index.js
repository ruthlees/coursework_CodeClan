
var makeRequest = function(url, callback){
  // create a new XmlHTTPRequest object
  var request = new XMLHttpRequest();

  // set the type of request, and the URL
  request.open("GET", url);

  // set the callback we want it to use when the requst is complete
  request.onload = callback;

  // send the request
  request.send();
};

var requestComplete = function(){
  if(this.status !== 200){
    return;
  }
  // grab the response text
  var jsonString = this.responseText;
  var countries = JSON.parse(jsonString);
  populateList(countries);
  // // console.log(country);
};

var populateList = function(countries){
  var selectCountries = document.querySelector("select");

  countries.forEach(function(country){
    var option = document.createElement('option');
    option.innerText = country.name;  // the name(innerText) in the selector
    option.value = country.alpha3Code; // but it is the country's code which is being used in find
    selectCountries.appendChild(option);
  });
  selectCountries.onchange = handleCountryChange
};


var handleCountryChange = function(){
  var url = "https://restcountries.eu/rest/v2/alpha/" + this.value
  makeRequest(url, getCountryInfo);
}

var getCountryInfo = function(){
  if(this.status !== 200){
    return;
  }
  var jsonString = this.responseText;
  var countryInfo = JSON.parse(jsonString);
  // console.log(countryInfo)
  makeInfo(countryInfo);
};

var makeInfo = function(countryInfo) {
  var info = document.querySelector('info');

  country.forEach(function(key){
    
  })

}
//   countryInfo.forEach(function(key){
//     var type = document.createElement('type'); 
//   })
// }

// var createCountryName = function(name){
//   var countryName = document.getElementById('#name');
//   countryName.innerText = "Country: " + country.name;
//   return countryName;
// }

// var createCountryPop = function(population){
//   var countryPop = document.getElementById('#population');
//    countryPop.innerText = "Population: " + country.population;
//   return countryPop;
// }

// var createCountryCapital = function(capital){
//    var countryCapital = document.getElementById('#capital');
//    countryCapital.innerText = "Capital: " + country.captial;
//    return countryCapital;
//  }


var app = function(){
  var url = "https://restcountries.eu/rest/v2/all";

  var urlCountry = "https://restcountries.eu/rest/v2/name/" + "";

  makeRequest(url, requestComplete);

};

window.onload = app;