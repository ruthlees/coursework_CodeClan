public interface AthleteLog {


public void log();


}