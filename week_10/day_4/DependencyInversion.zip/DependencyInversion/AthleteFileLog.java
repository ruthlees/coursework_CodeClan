public class AthleteLog implements AthleteLog {


  
}